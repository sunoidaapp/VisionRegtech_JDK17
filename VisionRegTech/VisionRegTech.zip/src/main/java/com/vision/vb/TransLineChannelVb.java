package com.vision.vb;

public class TransLineChannelVb extends CommonVb{

	private String transLineId = "";
	private String channelIdAT = null;
	private String channelId = "";
	
	public String getTransLineId() {
		return transLineId;
	}

	public void setTransLineId(String transLineId) {
		this.transLineId = transLineId;
	}

	public String getChannelId() {
		return channelId;
	}

	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}

	public String getChannelIdAT() {
		return channelIdAT;
	}

	public void setChannelIdAT(String channelIdAT) {
		this.channelIdAT = channelIdAT;
	}
}
