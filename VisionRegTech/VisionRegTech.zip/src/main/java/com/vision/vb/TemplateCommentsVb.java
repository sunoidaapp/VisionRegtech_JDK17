package com.vision.vb;

public class TemplateCommentsVb extends TemplateScheduleVb {

}
