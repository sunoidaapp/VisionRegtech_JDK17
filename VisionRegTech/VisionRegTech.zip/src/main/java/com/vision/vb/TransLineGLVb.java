package com.vision.vb;

public class TransLineGLVb extends CommonVb{

	private String transLineId = "";
	private String bsGl = "";
	private String bsGlDesc = "";
	private String bAcid = "";
	private String bAcidDesc = "";
	private String productType = "";
	private String productTypeDesc = "";
	private String productID = "";
	private String productIDDesc = "";
	private String ccyCode = "";
	private int transLineGLStatusNT = 1;
	private int transLineGLStatus = 0;

	public String getTransLineId() {
		return transLineId;
	}

	public void setTransLineId(String transLineId) {
		this.transLineId = transLineId;
	}

	public String getBsGl() {
		return bsGl;
	}

	public void setBsGl(String bsGl) {
		this.bsGl = bsGl;
	}
	public String getProductID() {
		return productID;
	}

	public void setProductID(String productID) {
		this.productID = productID;
	}

	public String getCcyCode() {
		return ccyCode;
	}

	public void setCcyCode(String ccyCode) {
		this.ccyCode = ccyCode;
	}

	public String getProductIDDesc() {
		return productIDDesc;
	}

	public void setProductIDDesc(String productIDDesc) {
		this.productIDDesc = productIDDesc;
	}

	public String getbAcid() {
		return bAcid;
	}

	public void setbAcid(String bAcid) {
		this.bAcid = bAcid;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public String getProductTypeDesc() {
		return productTypeDesc;
	}

	public void setProductTypeDesc(String productTypeDesc) {
		this.productTypeDesc = productTypeDesc;
	}

	public int getTransLineGLStatusNT() {
		return transLineGLStatusNT;
	}

	public void setTransLineGLStatusNT(int transLineGLStatusNT) {
		this.transLineGLStatusNT = transLineGLStatusNT;
	}

	public int getTransLineGLStatus() {
		return transLineGLStatus;
	}

	public void setTransLineGLStatus(int transLineGLStatus) {
		this.transLineGLStatus = transLineGLStatus;
	}

	public String getBsGlDesc() {
		return bsGlDesc;
	}

	public void setBsGlDesc(String bsGlDesc) {
		this.bsGlDesc = bsGlDesc;
	}

	public String getbAcidDesc() {
		return bAcidDesc;
	}

	public void setbAcidDesc(String bAcidDesc) {
		this.bAcidDesc = bAcidDesc;
	}
}
