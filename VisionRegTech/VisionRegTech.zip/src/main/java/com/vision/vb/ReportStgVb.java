package com.vision.vb;

import java.io.Serializable;
import java.util.List;


public class ReportStgVb implements Serializable{

	private static final long serialVersionUID = 1L;
	private String reportId = "";
	private String sessionId = ""; 
	private String captionColumn1 =  "";
	private String captionColumn2 =  "";
	private String captionColumn3 =  "";
	private String captionColumn4 =  "";
	private String captionColumn5 =  "";
	private String captionColumn6 =  "";
	private String dataColumn1 = "";
	private String dataColumn2 = "";
	private String dataColumn3 = "";
	private String dataColumn4 = "";
	private String dataColumn5 = "";
	private String dataColumn6 = "";
	private String dataColumn7 = "";
	private String dataColumn8 = "";
	private String dataColumn9 = "";
	private String dataColumn10 = ""; 
	private String dataColumn11 = ""; 
	private String dataColumn12 = ""; 
	private String dataColumn13 = ""; 
	private String dataColumn14 = ""; 
	private String dataColumn15 = ""; 
	private String dataColumn16 = ""; 
	private String dataColumn17 = ""; 
	private String dataColumn18 = ""; 
	private String dataColumn19 = ""; 
	private String dataColumn20 = ""; 
	private String dataColumn21 = ""; 
	private String dataColumn22 = ""; 
	private String dataColumn23 = ""; 
	private String dataColumn24 = ""; 
	private String dataColumn25 = ""; 
	private String dataColumn26 = ""; 
	private String dataColumn27 = ""; 
	private String dataColumn28 = ""; 
	private String dataColumn29 = ""; 
	private String dataColumn30 = ""; 
	private String dataColumn31 = ""; 
	private String dataColumn32 = ""; 
	private String dataColumn33 = ""; 
	private String dataColumn34 = ""; 
	private String dataColumn35 = ""; 
	private String dataColumn36 = ""; 
	private String dataColumn37 = ""; 
	private String dataColumn38 = ""; 
	private String dataColumn39 = ""; 
	private String dataColumn40 = "";
	private String formatType = "";
	private String boldFlag = "";
	private String ddKeyFieldId = "";
	private String ddKeyFieldValue = "";
	private String ddKeyFieldLabel = "";
	
	List<ReportStgVb> detailReportlst = null;
	
	public String getReportId() {
		return reportId;
	}
	public void setReportId(String reportId) {
		this.reportId = reportId;
	}
	public String getSessionId() {
		return sessionId;
	}
	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}
	public String getCaptionColumn1() {
		return captionColumn1;
	}
	public void setCaptionColumn1(String captionColumn1) {
		this.captionColumn1 = captionColumn1;
	}
	public String getCaptionColumn2() {
		return captionColumn2;
	}
	public void setCaptionColumn2(String captionColumn2) {
		this.captionColumn2 = captionColumn2;
	}
	public String getCaptionColumn3() {
		return captionColumn3;
	}
	public void setCaptionColumn3(String captionColumn3) {
		this.captionColumn3 = captionColumn3;
	}
	public String getDataColumn1() {
		return dataColumn1;
	}
	public void setDataColumn1(String dataColumn1) {
		this.dataColumn1 = dataColumn1;
	}
	public String getDataColumn2() {
		return dataColumn2;
	}
	public void setDataColumn2(String dataColumn2) {
		this.dataColumn2 = dataColumn2;
	}
	public String getDataColumn3() {
		return dataColumn3;
	}
	public void setDataColumn3(String dataColumn3) {
		this.dataColumn3 = dataColumn3;
	}
	public String getDataColumn4() {
		return dataColumn4;
	}
	public void setDataColumn4(String dataColumn4) {
		this.dataColumn4 = dataColumn4;
	}
	public String getDataColumn5() {
		return dataColumn5;
	}
	public void setDataColumn5(String dataColumn5) {
		this.dataColumn5 = dataColumn5;
	}
	public String getDataColumn6() {
		return dataColumn6;
	}
	public void setDataColumn6(String dataColumn6) {
		this.dataColumn6 = dataColumn6;
	}
	public String getDataColumn7() {
		return dataColumn7;
	}
	public void setDataColumn7(String dataColumn7) {
		this.dataColumn7 = dataColumn7;
	}
	public String getDataColumn8() {
		return dataColumn8;
	}
	public void setDataColumn8(String dataColumn8) {
		this.dataColumn8 = dataColumn8;
	}
	public String getDataColumn9() {
		return dataColumn9;
	}
	public void setDataColumn9(String dataColumn9) {
		this.dataColumn9 = dataColumn9;
	}
	public String getDataColumn10() {
		return dataColumn10;
	}
	public void setDataColumn10(String dataColumn10) {
		this.dataColumn10 = dataColumn10;
	}
	public String getDataColumn11() {
		return dataColumn11;
	}
	public void setDataColumn11(String dataColumn11) {
		this.dataColumn11 = dataColumn11;
	}
	public String getDataColumn12() {
		return dataColumn12;
	}
	public void setDataColumn12(String dataColumn12) {
		this.dataColumn12 = dataColumn12;
	}
	public String getDataColumn13() {
		return dataColumn13;
	}
	public void setDataColumn13(String dataColumn13) {
		this.dataColumn13 = dataColumn13;
	}
	public String getDataColumn14() {
		return dataColumn14;
	}
	public void setDataColumn14(String dataColumn14) {
		this.dataColumn14 = dataColumn14;
	}
	public String getDataColumn15() {
		return dataColumn15;
	}
	public void setDataColumn15(String dataColumn15) {
		this.dataColumn15 = dataColumn15;
	}
	public String getDataColumn16() {
		return dataColumn16;
	}
	public void setDataColumn16(String dataColumn16) {
		this.dataColumn16 = dataColumn16;
	}
	public String getDataColumn17() {
		return dataColumn17;
	}
	public void setDataColumn17(String dataColumn17) {
		this.dataColumn17 = dataColumn17;
	}
	public String getDataColumn18() {
		return dataColumn18;
	}
	public void setDataColumn18(String dataColumn18) {
		this.dataColumn18 = dataColumn18;
	}
	public String getDataColumn19() {
		return dataColumn19;
	}
	public void setDataColumn19(String dataColumn19) {
		this.dataColumn19 = dataColumn19;
	}
	public String getDataColumn20() {
		return dataColumn20;
	}
	public void setDataColumn20(String dataColumn20) {
		this.dataColumn20 = dataColumn20;
	}
	public String getDataColumn21() {
		return dataColumn21;
	}
	public void setDataColumn21(String dataColumn21) {
		this.dataColumn21 = dataColumn21;
	}
	public String getDataColumn22() {
		return dataColumn22;
	}
	public void setDataColumn22(String dataColumn22) {
		this.dataColumn22 = dataColumn22;
	}
	public String getDataColumn23() {
		return dataColumn23;
	}
	public void setDataColumn23(String dataColumn23) {
		this.dataColumn23 = dataColumn23;
	}
	public String getDataColumn24() {
		return dataColumn24;
	}
	public void setDataColumn24(String dataColumn24) {
		this.dataColumn24 = dataColumn24;
	}
	public String getDataColumn25() {
		return dataColumn25;
	}
	public void setDataColumn25(String dataColumn25) {
		this.dataColumn25 = dataColumn25;
	}
	public String getDataColumn26() {
		return dataColumn26;
	}
	public void setDataColumn26(String dataColumn26) {
		this.dataColumn26 = dataColumn26;
	}
	public String getDataColumn27() {
		return dataColumn27;
	}
	public void setDataColumn27(String dataColumn27) {
		this.dataColumn27 = dataColumn27;
	}
	public String getDataColumn28() {
		return dataColumn28;
	}
	public void setDataColumn28(String dataColumn28) {
		this.dataColumn28 = dataColumn28;
	}
	public String getDataColumn29() {
		return dataColumn29;
	}
	public void setDataColumn29(String dataColumn29) {
		this.dataColumn29 = dataColumn29;
	}
	public String getDataColumn30() {
		return dataColumn30;
	}
	public void setDataColumn30(String dataColumn30) {
		this.dataColumn30 = dataColumn30;
	}
	public String getDataColumn31() {
		return dataColumn31;
	}
	public void setDataColumn31(String dataColumn31) {
		this.dataColumn31 = dataColumn31;
	}
	public String getDataColumn32() {
		return dataColumn32;
	}
	public void setDataColumn32(String dataColumn32) {
		this.dataColumn32 = dataColumn32;
	}
	public String getDataColumn33() {
		return dataColumn33;
	}
	public void setDataColumn33(String dataColumn33) {
		this.dataColumn33 = dataColumn33;
	}
	public String getDataColumn34() {
		return dataColumn34;
	}
	public void setDataColumn34(String dataColumn34) {
		this.dataColumn34 = dataColumn34;
	}
	public String getDataColumn35() {
		return dataColumn35;
	}
	public void setDataColumn35(String dataColumn35) {
		this.dataColumn35 = dataColumn35;
	}
	public String getDataColumn36() {
		return dataColumn36;
	}
	public void setDataColumn36(String dataColumn36) {
		this.dataColumn36 = dataColumn36;
	}
	public String getDataColumn37() {
		return dataColumn37;
	}
	public void setDataColumn37(String dataColumn37) {
		this.dataColumn37 = dataColumn37;
	}
	public String getDataColumn38() {
		return dataColumn38;
	}
	public void setDataColumn38(String dataColumn38) {
		this.dataColumn38 = dataColumn38;
	}
	public String getDataColumn39() {
		return dataColumn39;
	}
	public void setDataColumn39(String dataColumn39) {
		this.dataColumn39 = dataColumn39;
	}
	public String getDataColumn40() {
		return dataColumn40;
	}
	public void setDataColumn40(String dataColumn40) {
		this.dataColumn40 = dataColumn40;
	}
	public String getFormatType() {
		return formatType;
	}
	public void setFormatType(String formatType) {
		this.formatType = formatType;
	}
	public String getDdKeyFieldId() {
		return ddKeyFieldId;
	}
	public void setDdKeyFieldId(String ddKeyFieldId) {
		this.ddKeyFieldId = ddKeyFieldId;
	}
	public String getDdKeyFieldValue() {
		return ddKeyFieldValue;
	}
	public void setDdKeyFieldValue(String ddKeyFieldValue) {
		this.ddKeyFieldValue = ddKeyFieldValue;
	}
	public String getDdKeyFieldLabel() {
		return ddKeyFieldLabel;
	}
	public void setDdKeyFieldLabel(String ddKeyFieldLabel) {
		this.ddKeyFieldLabel = ddKeyFieldLabel;
	}
	public String getCaptionColumn4() {
		return captionColumn4;
	}
	public void setCaptionColumn4(String captionColumn4) {
		this.captionColumn4 = captionColumn4;
	}
	public String getCaptionColumn5() {
		return captionColumn5;
	}
	public void setCaptionColumn5(String captionColumn5) {
		this.captionColumn5 = captionColumn5;
	}
	public String getCaptionColumn6() {
		return captionColumn6;
	}
	public void setCaptionColumn6(String captionColumn6) {
		this.captionColumn6 = captionColumn6;
	}
	public String getBoldFlag() {
		return boldFlag;
	}
	public void setBoldFlag(String boldFlag) {
		this.boldFlag = boldFlag;
	}
	public List<ReportStgVb> getDetailReportlst() {
		return detailReportlst;
	}
	public void setDetailReportlst(List<ReportStgVb> detailReportlst) {
		this.detailReportlst = detailReportlst;
	}
}
