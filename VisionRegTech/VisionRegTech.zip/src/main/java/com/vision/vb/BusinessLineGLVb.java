package com.vision.vb;

public class BusinessLineGLVb extends CommonVb{

	private String businessLineId = "";
	private String plGl = "";
	private String plGlDesc = "";
	private String bAcid = "";
	private String bAcidDesc = "";
	
	public String getPlGl() {
		return plGl;
	}
	public void setPlGl(String plGl) {
		this.plGl = plGl;
	}
	public String getbAcid() {
		return bAcid;
	}
	public void setbAcid(String bAcid) {
		this.bAcid = bAcid;
	}
	public String getPlGlDesc() {
		return plGlDesc;
	}
	public void setPlGlDesc(String plGlDesc) {
		this.plGlDesc = plGlDesc;
	}
	public String getbAcidDesc() {
		return bAcidDesc;
	}
	public void setbAcidDesc(String bAcidDesc) {
		this.bAcidDesc = bAcidDesc;
	}
	public String getBusinessLineId() {
		return businessLineId;
	}
	public void setBusinessLineId(String businessLineId) {
		this.businessLineId = businessLineId;
	}
}
