package com.vision.vb;

public class AccountsMappingVb extends CommonVb{
		private String	accountNo = "";
		private String	productDr = "";
		private String	productCr = "";
		private String	frlLineBsDr = "";
		private String	frlLineBsCr = "";
		private String	frlLinePlDr = "";
		private String	frlLinePlCr = "";
		private String	mrlLineDr = "";
		private String	mrlLineCr = "";
		private int	accountsMappingStatusNt = 0;
		private int	accountsMappingStatus = -1;
		private String	accountNoDesc = "";
		private String	frlLineBsDrDesc = "";
		private String	frlLineBsCrDesc = "";
		private String	frlLinePlDrDesc = "";
		private String	frlLinePlCrDesc = "";
		private String	mrlLineDrDesc = "";
		private String	mrlLineCrDesc = "";
		private String	productDrDesc = "";
		private String	productCrDesc = "";
		
		public String getAccountNo() {
			return accountNo;
		}
		public void setAccountNo(String accountNo) {
			this.accountNo = accountNo;
		}
		public String getProductDr() {
			return productDr;
		}
		public void setProductDr(String productDr) {
			this.productDr = productDr;
		}
		public String getProductCr() {
			return productCr;
		}
		public void setProductCr(String productCr) {
			this.productCr = productCr;
		}
		public String getFrlLineBsDr() {
			return frlLineBsDr;
		}
		public void setFrlLineBsDr(String frlLineBsDr) {
			this.frlLineBsDr = frlLineBsDr;
		}
		public String getFrlLineBsCr() {
			return frlLineBsCr;
		}
		public void setFrlLineBsCr(String frlLineBsCr) {
			this.frlLineBsCr = frlLineBsCr;
		}
		public String getFrlLinePlDr() {
			return frlLinePlDr;
		}
		public void setFrlLinePlDr(String frlLinePlDr) {
			this.frlLinePlDr = frlLinePlDr;
		}
		public String getFrlLinePlCr() {
			return frlLinePlCr;
		}
		public void setFrlLinePlCr(String frlLinePlCr) {
			this.frlLinePlCr = frlLinePlCr;
		}
		public String getMrlLineDr() {
			return mrlLineDr;
		}
		public void setMrlLineDr(String mrlLineDr) {
			this.mrlLineDr = mrlLineDr;
		}
		public String getMrlLineCr() {
			return mrlLineCr;
		}
		public void setMrlLineCr(String mrlLineCr) {
			this.mrlLineCr = mrlLineCr;
		}
		public int getAccountsMappingStatusNt() {
			return accountsMappingStatusNt;
		}
		public void setAccountsMappingStatusNt(int accountsMappingStatusNt) {
			this.accountsMappingStatusNt = accountsMappingStatusNt;
		}
		public int getAccountsMappingStatus() {
			return accountsMappingStatus;
		}
		public void setAccountsMappingStatus(int accountsMappingStatus) {
			this.accountsMappingStatus = accountsMappingStatus;
		}
		public String getAccountNoDesc() {
			return accountNoDesc;
		}
		public void setAccountNoDesc(String accountNoDesc) {
			this.accountNoDesc = accountNoDesc;
		}
		public String getFrlLineBsDrDesc() {
			return frlLineBsDrDesc;
		}
		public void setFrlLineBsDrDesc(String frlLineBsDrDesc) {
			this.frlLineBsDrDesc = frlLineBsDrDesc;
		}
		public String getFrlLineBsCrDesc() {
			return frlLineBsCrDesc;
		}
		public void setFrlLineBsCrDesc(String frlLineBsCrDesc) {
			this.frlLineBsCrDesc = frlLineBsCrDesc;
		}
		public String getFrlLinePlDrDesc() {
			return frlLinePlDrDesc;
		}
		public void setFrlLinePlDrDesc(String frlLinePlDrDesc) {
			this.frlLinePlDrDesc = frlLinePlDrDesc;
		}
		public String getFrlLinePlCrDesc() {
			return frlLinePlCrDesc;
		}
		public void setFrlLinePlCrDesc(String frlLinePlCrDesc) {
			this.frlLinePlCrDesc = frlLinePlCrDesc;
		}
		public String getMrlLineDrDesc() {
			return mrlLineDrDesc;
		}
		public void setMrlLineDrDesc(String mrlLineDrDesc) {
			this.mrlLineDrDesc = mrlLineDrDesc;
		}
		public String getMrlLineCrDesc() {
			return mrlLineCrDesc;
		}
		public void setMrlLineCrDesc(String mrlLineCrDesc) {
			this.mrlLineCrDesc = mrlLineCrDesc;
		}
		public String getProductDrDesc() {
			return productDrDesc;
		}
		public void setProductDrDesc(String productDrDesc) {
			this.productDrDesc = productDrDesc;
		}
		public String getProductCrDesc() {
			return productCrDesc;
		}
		public void setProductCrDesc(String productCrDesc) {
			this.productCrDesc = productCrDesc;
		}
}
