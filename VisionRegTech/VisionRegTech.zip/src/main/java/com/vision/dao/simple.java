package com.vision.dao;

public class simple {
public static void main(String[] args) {
	System.out.println("HI ");
}
}
