package com.vision.dao;

import org.springframework.stereotype.Component;

import com.vision.vb.CustomersVb;

@Component
public class CustomerExtrasDao extends AbstractDao<CustomersVb> {
	
}
